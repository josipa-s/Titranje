import React, { useRef, useEffect } from "react";
import { Stage, Layer, Line, Text, Circle } from 'react-konva';
import { useLocation } from "react-router-dom";
import { InlineMath, BlockMath } from "react-katex"


export const calculateAmplitude = (omega, m, k, b, F0) => {
    return F0 / Math.sqrt(Math.pow(k - m * omega * omega, 2) + Math.pow(b * omega, 2));
  };
  
  export const AmplitudeFrequencyGraph = ({ m, k, b, F0, omegaMin, omegaMax, omegaStep, graphWidth, graphHeight, amplitude, omegap }) => {
    const points = useRef([]);
    const xLabels = useRef([]);
    const yLabels = useRef([]);
  
    useEffect(() => {
      const frequencies = [];
      const amplitudes = [];
      
      for (let omega = omegaMin; omega <= omegaMax; omega += omegaStep) {
        const amplitude = calculateAmplitude(omega, m, k, b, Math.abs(F0));
        frequencies.push(omega);
        amplitudes.push(amplitude);
      }
  
      const xScale = graphWidth / (omegaMax - omegaMin);
      const yScale = graphHeight / Math.max(...amplitudes);
  
      points.current = frequencies.map((omega, index) => ({
        x: (omega - omegaMin) * xScale,
        y: graphHeight - amplitudes[index] * yScale
      }));
  
      xLabels.current = frequencies.map((omega, index) => ({
        x: (omega - omegaMin) * xScale,
        y: graphHeight + 15,
        label: index % 5 === 0 ? omega.toFixed(1) : ''
      }));
  
      const yMax = Math.max(...amplitudes);
      yLabels.current = [
        { x: 5, y: 0, label: yMax.toFixed(2) },
        { x: 5, y: graphHeight / 2, label: (yMax / 2).toFixed(2) },
      ];
      const x = (omegap - omegaMin) * xScale;
    }, [m, k, b, F0]);

    const currentX = (omegap - omegaMin) * (graphWidth / (omegaMax - omegaMin));
    const currentY = graphHeight - amplitude * (graphHeight / Math.max(...points.current.map(p => graphHeight - p.y)));

  
    return (
      <>
      <p>Graf ovisnosti amplitude o frekvenciji</p>
      <InlineMath>A</InlineMath>
      <Stage width={graphWidth} height={graphHeight + 30}>
        <Layer>
          <Line points={[0, 0, 0, graphHeight]} stroke="black" strokeWidth={1} />
          <Line points={[0, graphHeight, graphWidth, graphHeight]} stroke="black" strokeWidth={1} />
  
          {points.current.length > 1 && (
            <Line
              points={points.current.flatMap(point => [point.x, point.y])}
              stroke="cadetblue"
              strokeWidth={2}
              tension={0.1}
              lineCap="round"
              lineJoin="round"
            />
          )}
  
          {xLabels.current.map((label, index) => (
            <Text key={index} x={label.x} y={label.y} text={label.label} fontSize={12} />
          ))}
  
          {yLabels.current.map((label, index) => (
            <Text key={index} x={label.x} y={label.y} text={label.label} fontSize={12} />
          ))}

          <Line
          points={[currentX, graphHeight, currentX, 0]}
          stroke={"black"}
          strokeWidth={2}
          dash={[0, 5]}
          lineCap="round"
          lineJoin="round"/>
        </Layer>
      </Stage>
      <div className="math-container">
        <InlineMath className={'graf'}>\omega_p</InlineMath>
      </div>
      </>
    );
  };

export const XvtGraphs = ({ canvasWidth, graphHeight, graphWidth, velocityPointsRef, positionPointsRef, aPointsRef, amplitude, v_max, a_max, period }) => {

    return (
        <>
        <p>Graf ovisnosti položaja o vremenu</p>
        <InlineMath>x(t)</InlineMath>
        <Stage width={graphWidth} height={graphHeight} >
            <Layer>
                <Line
                points={[0, graphHeight / 2, graphWidth, graphHeight / 2]}
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={1}></Line>
                <Line
                points={positionPointsRef}
                stroke={"cadetblue"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                />
                <Line
                points={[0, graphHeight, graphWidth, graphHeight]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={3}
                dash={[0, 5]}
                />
                <Line
                points={[0, 0, graphWidth, 0]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                dash={[0, 5]}
                />
                <Line
                points={[2, graphHeight, 0, 0]}
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={1}></Line>
                {/*<Text
                x={5}
                y={200 / 2 + 5}
                text='x(t)'
                fontSize={16}
                />*/}
                <Text 
                x={1}
                y={1}
                text={(-amplitude).toFixed(2)}
                />
                <Text 
                x={3}
                y={graphHeight - 13}
                text={amplitude.toFixed(2)}
                />
                
            </Layer>
        </Stage>
        <br></br>
        <p>Graf ovisnosti brzine o vremenu</p>
        <InlineMath>v(t)</InlineMath>
        <Stage width={graphWidth} height={graphHeight} >
            <Layer>
                <Line
                points={[0, graphHeight / 2, graphWidth, graphHeight / 2]}
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={1}></Line>
                <Line
                points={velocityPointsRef}
                stroke={"cadetblue"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                />
                <Line
                points={[0, graphHeight, graphWidth, graphHeight]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={3}
                dash={[0, 5]}
                />
                <Line
                points={[0, 0, graphWidth, 0]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                dash={[0, 5]}
                />
                <Line
                points={[2, graphHeight, 0, 0]}
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={1}></Line>
                <Text 
                x={1}
                y={1}
                text={v_max.toFixed(2)}
                />
                <Text 
                x={3}
                y={graphHeight - 13}
                text={(-v_max).toFixed(2)}
                />
            </Layer>
        </Stage>
        
        <br></br>
        <p>Graf ovisnosti akceleracije o vremenu</p>
        <InlineMath>a(t)</InlineMath>
        <Stage width={graphWidth} height={graphHeight} >
            <Layer>
                <Line
                points={[0, graphHeight / 2, graphWidth, graphHeight / 2]}
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={1}></Line>
                <Line
                points={aPointsRef}
                stroke={"cadetblue"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                />
                <Line
                points={[0, graphHeight, graphWidth, graphHeight]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={3}
                dash={[0, 5]}
                />
                <Line
                points={[0, 0, graphWidth, 0]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                dash={[0, 5]}
                />
                <Line
                points={[2, graphHeight, 0, 0]}
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={1}></Line>
                <Text 
                x={1}
                y={1}
                text={a_max.toFixed(2)}
                />
                <Text 
                x={3}
                y={graphHeight - 13}
                text={(-a_max).toFixed(2)}
                />
            </Layer>
        </Stage>
        <br></br>
    </>
    )
}

export const EGraphs = ({ graphWidth, graphHeight, uPoints, kPoints,uxPoints, kxPoints, uPoint, kPoint, ePoints, u_max, k_max, e_start, period, amplitude}) => {
    
    const location = useLocation();
    const path = location.pathname;

    return (
        <>
        <p>Graf ovisnosti energije o vremenu</p>
        <Stage width={graphWidth} height={graphHeight} >
            <Layer>
                {/* <Line
                points={[0, graphHeight / 2, graphWidth, graphHeight / 2]}
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
    strokeWidth={1}></Line> */}
                <Line
                points={uPoints}
                stroke={"cadetblue"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                />
                <Line
                points={kPoints}
                stroke={"red"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                />
                <Line
                points={[0, graphHeight, graphWidth, graphHeight]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={3}
                dash={[0, 5]}
                />
                <Line
                points={[0, 0, graphWidth, 0]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                dash={[0, 5]}
                />
                <Text
                x={5}
                y={200 / 2 + 10}
                text='U'
                fontSize={16}
                stroke={"cadetblue"}
                />
                <Text
                x={5}
                y={200 / 2 - 85}
                text='K'
                fontSize={16}
                stroke={"red"}
                />
                <Text 
                x={1}
                y={1}
                text={(u_max).toFixed(2)}
                />
                <Text 
                x={3}
                y={graphHeight - 13}
                text={0}
                />
            </Layer>
        </Stage>
        <br></br>
        { path !== '/priguseno' &&
        <>
        <p>Graf ovisnosti energije o položaju</p>
        <BlockMath>\\t</BlockMath>
        <Stage width={graphWidth} height={graphHeight} >
            <Layer>
               
                <Line
                points={[graphWidth / 2, 0, graphWidth / 2, graphHeight]}
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={1} />
                <Line
                points={uxPoints}
                stroke={"cadetblue"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                />
                <Line
                points={kxPoints}
                stroke={"red"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                />
                <Circle
                x={uPoint.x}
                y={uPoint.y}
                stroke={"black"} 
                radius={5}/>
                <Circle
                x={kPoint.x}
                y={kPoint.y}
                stroke={"black"} 
                radius={5}/>
                <Line
                points={[0, graphHeight, graphWidth, graphHeight]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={3}
                
                />
                <Line
                points={[0, 0, graphWidth, 0]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                dash={[0, 5]}
                />
                <Text
                x={5}
                y={200 / 2 + 10}
                text='U'
                fontSize={16}
                stroke={"cadetblue"}
                />
                <Text
                x={5}
                y={200 / 2 - 85}
                text='K'
                fontSize={16}
                stroke={"red"}
                />
                <Text 
                x={graphWidth / 2 + 1}
                y={1}
                text={(u_max).toFixed(2)}
                />
                <Text 
                x={graphWidth / 2 + 3}
                y={graphHeight - 13}
                text={0}
                />
                <Text 
                x={graphWidth / 2 + 1}
                y={1}
                text={(u_max).toFixed(2)}
                />
                <Text 
                x={3}
                y={graphHeight - 13}
                text={amplitude.toFixed(2)}
                />
                <Text 
                x={graphWidth - 35}
                y={graphHeight - 13}
                text={amplitude.toFixed(2)}
                />
            </Layer>
        </Stage>
        <InlineMath>A</InlineMath>
        </> }
        { path === '/priguseno' && 
        <>
        Graf ovisnosti ukupne energije o vremenu
        <Stage width={graphWidth} height={graphHeight} >
            <Layer>
                <Line
                points={ePoints}
                stroke={"cadetblue"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                />
                <Line
                points={[0, graphHeight, graphWidth, graphHeight]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={3}
                dash={[0, 5]}
                />
                <Line
                points={[0, 0, graphWidth, 0]} 
                stroke={"black"}
                tension={0.2}
                lineCap="round"
                lineJoin="round"
                strokeWidth={2}
                dash={[0, 5]}
                />
                <Text
                x={5}
                y={200 / 2 + 10}
                text='E'
                fontSize={16}
                stroke={"cadetblue"}
                />
            </Layer>
        </Stage> 
        </>}
        
        <br />
        </>
    )
}